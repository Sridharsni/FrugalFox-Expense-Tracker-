import React from "react";
import { ManyUpload } from "../../components/ManyUpload";
import { Title } from "../../components/Title";
import { UploadUrl } from "../../components/UploadUrl";
import { Close } from "../../icons/Close";
import { VuesaxLinearArrowDown1 } from "../../icons/VuesaxLinearArrowDown1";
import { VuesaxLinearElement41 } from "../../icons/VuesaxLinearElement41";
import { VuesaxLinearNotificationBing1 } from "../../icons/VuesaxLinearNotificationBing1";
import { VuesaxLinearSearchNormal1 } from "../../icons/VuesaxLinearSearchNormal1";
import "./style.css";

export const ProfileSetting = () => {
  return (
    <div className="profile-setting">
      <div className="div-2">
        <div className="group">
          <VuesaxLinearNotificationBing1 className="vuesax-linear" />
        </div>
        <div className="group-wrapper">
          <div className="group-2">
            <div className="text-wrapper-4">Welcome, Dhruv</div>
            <div className="text-wrapper-5">Tue, 07 June 2022</div>
          </div>
        </div>
        <div className="overlap-group-wrapper">
          <div className="overlap-group">
            <VuesaxLinearSearchNormal1 className="vuesax-linear-search" />
            <div className="text-wrapper-6">Search</div>
          </div>
        </div>
        <img className="rectangle-2" alt="Rectangle" src="/img/rectangle-6618.png" />
        <div className="overlap">
          <div className="rectangle-3" />
          <VuesaxLinearElement41 className="vuesax-linear-element-4-1" />
          <img className="rectangle-4" alt="Rectangle" src="/img/rectangle-6692.png" />
          <p className="provide-card-details">
            <span className="span">Provide Card </span>
            <span className="text-wrapper-7">Details</span>
          </p>
          <p className="p">Enter your future financial goals</p>
          <div className="text-wrapper-8">Full Name</div>
          <div className="text-wrapper-9">Currency</div>
          <div className="text-wrapper-10">Current Income</div>
          <p className="upload-financial">
            <span className="span">Upload </span>
            <span className="text-wrapper-7">financial</span>
            <span className="span"> statements / Bills</span>
          </p>
          <img className="rectangle-5" alt="Rectangle" src="/img/rectangle-6691.svg" />
          <img className="ellipse" alt="Ellipse" src="/img/ellipse-11-1.png" />
          <img className="ellipse" alt="Ellipse" src="/img/ellipse-11-1.png" />
          <div className="group-3">
            <div className="text-wrapper-11">Dhruv Singh</div>
            <div className="upload-step">
              <Title
                className="title-instance"
                desc
                descClassName="design-component-instance-node-2"
                div={false}
                divClassName="design-component-instance-node"
                icon={<Close className="style-round-3" color="#0B0B0B" />}
                text="Media Upload"
                text1="Add your documents here, and you can upload up to 5 files max"
                type="single-trailing"
              />
              <ManyUpload
                className="many-upload-instance"
                divClassName="design-component-instance-node"
                divClassName1="design-component-instance-node-2"
                divClassNameOverride="many-upload-2"
                states="default"
                style="base"
                text="Max 10 MB files are allowed"
              />
              <UploadUrl
                className="upload-URL-instance"
                divClassName="design-component-instance-node"
                divClassNameOverride="upload-URL-2"
                states="failed"
                text="Sep24_expense.pdf"
              />
            </div>
            <div className="text-wrapper-12">dhruvsingh@gmail.com</div>
          </div>
          <div className="overlap-wrapper">
            <div className="div-wrapper">
              <div className="text-wrapper-13">Edit</div>
            </div>
          </div>
          <div className="group-4">
            <div className="overlap-2">
              <div className="text-wrapper-13">Next</div>
            </div>
          </div>
          <div className="rectangle-6" />
          <div className="rectangle-7" />
          <VuesaxLinearArrowDown1 className="vuesax-linear-arrow" />
          <div className="rectangle-8" />
          <div className="rectangle-9" />
          <div className="text-wrapper-14">Enter text here</div>
          <div className="text-wrapper-15">Your Name</div>
          <div className="text-wrapper-16">Choose Currency</div>
          <div className="text-wrapper-17">Enter Income</div>
          <img className="ellipse-2" alt="Ellipse" src="/img/ellipse-7.svg" />
          <div className="frame-4">
            <div className="overlap-3">
              <div className="frame-5">
                <img className="logos-visa" alt="Logos visa" src="/img/logos-visa.svg" />
                <div className="text-wrapper-18">**** **** **** 4892</div>
                <div className="group-5">
                  <div className="text-wrapper-19">Expiry date: 04/2025</div>
                  <p className="CVV">
                    <span className="text-wrapper-20">CVV: </span>
                    <span className="text-wrapper-21">**5</span>
                  </p>
                </div>
                <div className="text-wrapper-22">Card holder: Dhruv</div>
              </div>
              <div className="ellipse-3" />
              <div className="ellipse-4" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
