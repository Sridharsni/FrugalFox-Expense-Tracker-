export { StyleTwoTone5 } from "./StyleTwoTone5";
