/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const StyleRound6 = ({ color = "black", className }) => {
  return (
    <svg
      className={`style-round-6 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 25 24"
      width="25"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M11.6666 18H13.6666C14.2166 18 14.6666 17.55 14.6666 17C14.6666 16.45 14.2166 16 13.6666 16H11.6666C11.1166 16 10.6666 16.45 10.6666 17C10.6666 17.55 11.1166 18 11.6666 18ZM3.66663 7C3.66663 7.55 4.11663 8 4.66663 8H20.6666C21.2166 8 21.6666 7.55 21.6666 7C21.6666 6.45 21.2166 6 20.6666 6H4.66663C4.11663 6 3.66663 6.45 3.66663 7ZM7.66663 13H17.6666C18.2166 13 18.6666 12.55 18.6666 12C18.6666 11.45 18.2166 11 17.6666 11H7.66663C7.11663 11 6.66663 11.45 6.66663 12C6.66663 12.55 7.11663 13 7.66663 13Z"
        fill={color}
      />
    </svg>
  );
};

StyleRound6.propTypes = {
  color: PropTypes.string,
};
