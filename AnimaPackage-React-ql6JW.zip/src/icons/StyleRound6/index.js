export { StyleRound6 } from "./StyleRound6";
