export { StyleSharp1 } from "./StyleSharp1";
