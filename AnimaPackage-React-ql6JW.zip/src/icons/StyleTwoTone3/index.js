export { StyleTwoTone3 } from "./StyleTwoTone3";
