export { IosStyle1 } from "./IosStyle1";
