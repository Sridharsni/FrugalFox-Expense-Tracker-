/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Info84 = ({ className }) => {
  return (
    <svg
      className={`info-84 ${className}`}
      fill="none"
      height="20"
      viewBox="0 0 20 20"
      width="20"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M9.16667 5.83335H10.8333V7.50002H9.16667V5.83335ZM9.16667 9.16669H10.8333V14.1667H9.16667V9.16669ZM10 1.66669C5.4 1.66669 1.66667 5.40002 1.66667 10C1.66667 14.6 5.4 18.3334 10 18.3334C14.6 18.3334 18.3333 14.6 18.3333 10C18.3333 5.40002 14.6 1.66669 10 1.66669ZM10 16.6667C6.325 16.6667 3.33333 13.675 3.33333 10C3.33333 6.32502 6.325 3.33335 10 3.33335C13.675 3.33335 16.6667 6.32502 16.6667 10C16.6667 13.675 13.675 16.6667 10 16.6667Z"
        fill="white"
      />
    </svg>
  );
};
