export { StyleSharp2 } from "./StyleSharp2";
