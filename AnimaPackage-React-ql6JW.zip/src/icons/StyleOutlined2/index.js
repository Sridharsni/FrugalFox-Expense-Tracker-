export { StyleOutlined2 } from "./StyleOutlined2";
