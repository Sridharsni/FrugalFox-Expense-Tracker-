export { VuesaxLinearArrowDown1 } from "./VuesaxLinearArrowDown1";
