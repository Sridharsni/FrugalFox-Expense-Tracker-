export { DeleteOutline } from "./DeleteOutline";
