/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const VuesaxLinearNotificationBing1 = ({ className }) => {
  return (
    <svg
      className={`vuesax-linear-notification-bing-1 ${className}`}
      fill="none"
      height="27"
      viewBox="0 0 29 27"
      width="29"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M14.3999 7.11084V10.7433"
        stroke="#ADA7A7"
        strokeLinecap="round"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />
      <path
        className="path"
        d="M14.424 2.26758C10.008 2.26758 6.43197 5.51822 6.43197 9.53244V11.8232C6.43197 12.5649 6.09597 13.6776 5.67597 14.3102L4.15197 16.6228C3.21598 18.0517 3.86397 19.6443 5.59197 20.1679C11.328 21.9023 17.532 21.9023 23.268 20.1679C24.888 19.6771 25.584 17.9536 24.708 16.6228L23.184 14.3102C22.764 13.6776 22.428 12.554 22.428 11.8232V9.53244C22.416 5.54004 18.816 2.26758 14.424 2.26758Z"
        stroke="#ADA7A7"
        strokeLinecap="round"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />
      <path
        className="path"
        d="M18.3961 20.6152C18.3961 22.6114 16.5961 24.2477 14.4001 24.2477C13.3081 24.2477 12.3001 23.8332 11.5801 23.1787C10.8601 22.5242 10.4041 21.6079 10.4041 20.6152"
        stroke="#ADA7A7"
        strokeMiterlimit="10"
        strokeWidth="1.5"
      />
    </svg>
  );
};
