/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const StyleRound = ({ className }) => {
  return (
    <svg
      className={`style-round ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M7 6.99994H17V8.78994C17 9.23994 17.54 9.45994 17.85 9.13994L20.64 6.34994C20.84 6.14994 20.84 5.83994 20.64 5.63994L17.85 2.84994C17.54 2.53994 17 2.75994 17 3.20994V4.99994H6C5.45 4.99994 5 5.44994 5 5.99994V9.99994C5 10.5499 5.45 10.9999 6 10.9999C6.55 10.9999 7 10.5499 7 9.99994V6.99994ZM17 16.9999H7V15.2099C7 14.7599 6.46 14.5399 6.15 14.8599L3.36 17.6499C3.16 17.8499 3.16 18.1599 3.36 18.3599L6.15 21.1499C6.46 21.4599 7 21.2399 7 20.7899V18.9999H18C18.55 18.9999 19 18.5499 19 17.9999V13.9999C19 13.4499 18.55 12.9999 18 12.9999C17.45 12.9999 17 13.4499 17 13.9999V16.9999Z"
        fill="black"
      />
    </svg>
  );
};
