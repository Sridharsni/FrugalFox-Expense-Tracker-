export { IosStyle2 } from "./IosStyle2";
