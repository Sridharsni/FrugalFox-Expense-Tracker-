export { IosStyle4 } from "./IosStyle4";
