/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IosStyle = ({ className }) => {
  return (
    <svg
      className={`ios-style ${className}`}
      fill="none"
      height="48"
      viewBox="0 0 48 48"
      width="48"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        clipRule="evenodd"
        d="M11.0307 11.0595C12.168 10.9949 13.3039 11.0001 14.4412 11.0001C14.449 11.0001 20.2039 11.0001 20.2039 11.0001C21.3634 11.0001 22.4993 10.9949 23.6359 11.0595C24.6693 11.1175 25.6758 11.2414 26.6778 11.5182C28.7869 12.1001 30.6287 13.3156 31.9601 15.0388C33.2836 16.7511 34 18.8472 34 20.9995C34 23.1543 33.2836 25.2491 31.9601 26.9614C30.6287 28.684 28.7869 29.9001 26.6778 30.482C25.6758 30.7588 24.6693 30.882 23.6359 30.9407C22.4993 31.0053 21.3634 30.9995 20.2261 30.9995C20.2183 30.9995 14.4621 31.0001 14.4621 31.0001C13.3039 30.9995 12.168 31.0053 11.0307 30.9407C9.99803 30.882 8.99149 30.7588 7.98953 30.482C5.88038 29.9001 4.03855 28.684 2.70718 26.9614C1.38365 25.2491 0.666656 23.1543 0.666656 21.0001C0.666656 18.8472 1.38365 16.7511 2.70718 15.0388C4.03855 13.3156 5.88038 12.1001 7.98953 11.5182C8.99149 11.2414 9.99803 11.1175 11.0307 11.0595Z"
        fill="#1849D6"
        fillRule="evenodd"
      />
      <g className="g" filter="url(#filter0_dd_617_570)">
        <path
          className="path"
          clipRule="evenodd"
          d="M24 29.6667C28.7864 29.6667 32.6666 25.7865 32.6666 21C32.6666 16.2135 28.7864 12.3333 24 12.3333C19.2135 12.3333 15.3333 16.2135 15.3333 21C15.3333 25.7865 19.2135 29.6667 24 29.6667Z"
          fill="white"
          fillRule="evenodd"
        />
      </g>
      <defs className="defs">
        <filter
          className="filter"
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
          height="47.3333"
          id="filter0_dd_617_570"
          width="47.3333"
          x="0.333313"
          y="0.333332"
        >
          <feFlood className="fe-flood" floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            className="fe-color-matrix"
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset className="fe-offset" dy="3" />
          <feGaussianBlur className="fe-gaussian-blur" stdDeviation="7.5" />
          <feColorMatrix
            className="fe-color-matrix"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend className="fe-blend" in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_617_570" />
          <feColorMatrix
            className="fe-color-matrix"
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset className="fe-offset" dy="3" />
          <feGaussianBlur className="fe-gaussian-blur" stdDeviation="6" />
          <feColorMatrix
            className="fe-color-matrix"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0"
          />
          <feBlend
            className="fe-blend"
            in2="effect1_dropShadow_617_570"
            mode="normal"
            result="effect2_dropShadow_617_570"
          />
          <feBlend
            className="fe-blend"
            in="SourceGraphic"
            in2="effect2_dropShadow_617_570"
            mode="normal"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
};
