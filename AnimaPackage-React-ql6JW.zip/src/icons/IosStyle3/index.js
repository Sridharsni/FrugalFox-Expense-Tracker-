export { IosStyle3 } from "./IosStyle3";
