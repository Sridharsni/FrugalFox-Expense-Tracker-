export { VuesaxLinearElement4 } from "./VuesaxLinearElement4";
