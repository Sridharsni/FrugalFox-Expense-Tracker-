/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const VuesaxLinearSearchNormal1 = ({ className }) => {
  return (
    <svg
      className={`vuesax-linear-search-normal-1 ${className}`}
      fill="none"
      height="27"
      viewBox="0 0 30 27"
      width="30"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M14.1998 22.9932C20.4958 22.9932 25.5998 18.3536 25.5998 12.6304C25.5998 6.90716 20.4958 2.26758 14.1998 2.26758C7.90376 2.26758 2.7998 6.90716 2.7998 12.6304C2.7998 18.3536 7.90376 22.9932 14.1998 22.9932Z"
        stroke="#ADA7A7"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
      <path
        className="path"
        d="M26.7999 24.084L24.3999 21.9023"
        stroke="#ADA7A7"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.5"
      />
    </svg>
  );
};
