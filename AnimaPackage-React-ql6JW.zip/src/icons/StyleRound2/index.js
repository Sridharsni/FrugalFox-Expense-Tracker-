export { StyleRound2 } from "./StyleRound2";
