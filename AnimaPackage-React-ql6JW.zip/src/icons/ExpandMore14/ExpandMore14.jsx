/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";

export const ExpandMore14 = ({ color = "#0B0B0B", className }) => {
  return (
    <svg
      className={`expand-more-14 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 25 24"
      width="25"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M16.5416 8.99999L12.6616 12.88L8.7816 8.99999C8.3916 8.60999 7.7616 8.60999 7.3716 8.99999C6.9816 9.38999 6.9816 10.02 7.3716 10.41L11.9616 15C12.3516 15.39 12.9816 15.39 13.3716 15L17.9616 10.41C18.3516 10.02 18.3516 9.38999 17.9616 8.99999C17.5716 8.61999 16.9316 8.60999 16.5416 8.99999Z"
        fill={color}
      />
    </svg>
  );
};

ExpandMore14.propTypes = {
  color: PropTypes.string,
};
