export { VuesaxLinearElement41 } from "./VuesaxLinearElement41";
