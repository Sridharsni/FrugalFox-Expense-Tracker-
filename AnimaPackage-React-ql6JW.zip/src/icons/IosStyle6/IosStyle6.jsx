/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const IosStyle6 = ({ className }) => {
  return (
    <svg
      className={`ios-style-6 ${className}`}
      fill="none"
      height="47"
      viewBox="0 0 48 47"
      width="48"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        clipRule="evenodd"
        d="M11.0307 10.0595C12.168 9.99494 13.3039 10.0001 14.4412 10.0001C14.449 10.0001 20.2039 10.0001 20.2039 10.0001C21.3634 10.0001 22.4994 9.99494 23.636 10.0595C24.6693 10.1175 25.6758 10.2414 26.6778 10.5182C28.7869 11.1001 30.6288 12.3156 31.9601 14.0388C33.2837 15.7511 34 17.8472 34 19.9995C34 22.1543 33.2837 24.2491 31.9601 25.9614C30.6288 27.684 28.7869 28.9001 26.6778 29.482C25.6758 29.7588 24.6693 29.882 23.636 29.9407C22.4994 30.0053 21.3634 29.9995 20.2262 29.9995C20.2183 29.9995 14.4621 30.0001 14.4621 30.0001C13.3039 29.9995 12.168 30.0053 11.0307 29.9407C9.99806 29.882 8.99152 29.7588 7.98956 29.482C5.88041 28.9001 4.03858 27.684 2.70721 25.9614C1.38368 24.2491 0.666687 22.1543 0.666687 20.0001C0.666687 17.8472 1.38368 15.7511 2.70721 14.0388C4.03858 12.3156 5.88041 11.1001 7.98956 10.5182C8.99152 10.2414 9.99806 10.1175 11.0307 10.0595Z"
        fill="#1849D6"
        fillRule="evenodd"
      />
      <g className="g" filter="url(#filter0_dd_608_1043)">
        <path
          className="path"
          clipRule="evenodd"
          d="M24 28.6667C28.7865 28.6667 32.6667 24.7865 32.6667 20C32.6667 15.2135 28.7865 11.3333 24 11.3333C19.2135 11.3333 15.3333 15.2135 15.3333 20C15.3333 24.7865 19.2135 28.6667 24 28.6667Z"
          fill="white"
          fillRule="evenodd"
        />
      </g>
      <defs className="defs">
        <filter
          className="filter"
          colorInterpolationFilters="sRGB"
          filterUnits="userSpaceOnUse"
          height="47.3333"
          id="filter0_dd_608_1043"
          width="47.3333"
          x="0.333344"
          y="-0.666656"
        >
          <feFlood className="fe-flood" floodOpacity="0" result="BackgroundImageFix" />
          <feColorMatrix
            className="fe-color-matrix"
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset className="fe-offset" dy="3" />
          <feGaussianBlur className="fe-gaussian-blur" stdDeviation="7.5" />
          <feColorMatrix
            className="fe-color-matrix"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.15 0"
          />
          <feBlend className="fe-blend" in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_608_1043" />
          <feColorMatrix
            className="fe-color-matrix"
            in="SourceAlpha"
            result="hardAlpha"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          />
          <feOffset className="fe-offset" dy="3" />
          <feGaussianBlur className="fe-gaussian-blur" stdDeviation="6" />
          <feColorMatrix
            className="fe-color-matrix"
            type="matrix"
            values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0"
          />
          <feBlend
            className="fe-blend"
            in2="effect1_dropShadow_608_1043"
            mode="normal"
            result="effect2_dropShadow_608_1043"
          />
          <feBlend
            className="fe-blend"
            in="SourceGraphic"
            in2="effect2_dropShadow_608_1043"
            mode="normal"
            result="shape"
          />
        </filter>
      </defs>
    </svg>
  );
};
