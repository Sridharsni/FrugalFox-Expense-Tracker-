export { IosStyle6 } from "./IosStyle6";
