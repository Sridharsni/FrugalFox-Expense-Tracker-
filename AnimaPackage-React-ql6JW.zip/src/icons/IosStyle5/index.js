export { IosStyle5 } from "./IosStyle5";
