/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const StyleTwoTone2 = ({ className }) => {
  return (
    <svg
      className={`style-two-tone-2 ${className}`}
      fill="none"
      height="24"
      viewBox="0 0 24 24"
      width="24"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M19.21 12.04L17.68 11.93L17.38 10.43C16.88 7.86 14.62 6 12 6C9.94 6 8.08 7.14 7.12 8.96L6.62 9.91L5.55 10.02C3.53 10.24 2 11.95 2 14C2 16.21 3.79 18 6 18H19C20.65 18 22 16.65 22 15C22 13.45 20.78 12.14 19.21 12.04ZM13.45 13V16H10.54V13H8L12 9L16 13H13.45Z"
        fill="black"
        opacity="0.3"
      />
      <path
        className="path"
        d="M19.35 10.04C18.67 6.59 15.64 4 12 4C9.11 4 6.6 5.64 5.35 8.04C2.34 8.36 0 10.91 0 14C0 17.31 2.69 20 6 20H19C21.76 20 24 17.76 24 15C24 12.36 21.95 10.22 19.35 10.04ZM19 18H6C3.79 18 2 16.21 2 14C2 11.95 3.53 10.24 5.56 10.03L6.63 9.92L7.13 8.97C8.08 7.14 9.94 6 12 6C14.62 6 16.88 7.86 17.39 10.43L17.69 11.93L19.22 12.04C20.78 12.14 22 13.45 22 15C22 16.65 20.65 18 19 18ZM8 13H10.55V16H13.45V13H16L12 9L8 13Z"
        fill="black"
      />
    </svg>
  );
};
