export { StyleTwoTone2 } from "./StyleTwoTone2";
