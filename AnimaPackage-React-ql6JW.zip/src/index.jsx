import React from "react";
import ReactDOMClient from "react-dom/client";
import { ProfileSetting } from "./screens/ProfileSetting";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<ProfileSetting />);
