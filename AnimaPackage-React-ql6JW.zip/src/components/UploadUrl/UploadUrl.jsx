/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { DeleteOutline } from "../../icons/DeleteOutline";
import { HighlightOff1 } from "../../icons/HighlightOff1";
import { PauseCircle } from "../../icons/PauseCircle";
import { Repeat } from "../../icons/Repeat";
import "./style.css";

export const UploadUrl = ({ states, className, divClassName, text = "filename.jpg", divClassNameOverride }) => {
  return (
    <div className={`upload-URL states-0-${states} ${className}`}>
      {["active", "default", "disabled", "uploading-alt", "uploading"].includes(states) && (
        <>
          <div className="row">
            {states === "uploading" && <img className="rectangle" alt="Rectangle" src="/img/rectangle-1-1.png" />}

            {["uploading-alt", "uploading"].includes(states) && (
              <>
                <div className="text-2">
                  <div className="filename-jpg">
                    {states === "uploading" && <>{text}</>}

                    {states === "uploading-alt" && <>Uploading...</>}
                  </div>
                  <div className="element">
                    {states === "uploading" && <>500kb</>}

                    {states === "uploading-alt" && <>65%&nbsp;&nbsp;• 30 seconds remaining</>}
                  </div>
                </div>
                <div className="action">
                  {states === "uploading-alt" && <PauseCircle className="instance-node-2" />}

                  <HighlightOff1 className="instance-node-2" color={states === "uploading" ? "#858585" : "#FF3636"} />
                </div>
              </>
            )}

            {states === "default" && <>Add file URL</>}

            {["active", "disabled"].includes(states) && <>https://sharefile.xyz/file.jpg</>}
          </div>
          <div className="progress-linear">
            {states === "uploading" && (
              <>
                <div className="master-linear-wrapper">
                  <div className="master-linear-2" />
                </div>
                <div className="label">60%</div>
              </>
            )}

            {["active", "default", "disabled", "uploading-alt"].includes(states) && (
              <div className="master-outline-2">
                {["active", "default", "disabled"].includes(states) && <button className="button-3">Upload</button>}
              </div>
            )}
          </div>
        </>
      )}

      {["done", "failed"].includes(states) && (
        <div className="frame-3">
          <img
            className="rectangle"
            alt="Rectangle"
            src={states === "done" ? "/img/rectangle-1-2.png" : "/img/rectangle-1-1.png"}
          />
          <div className="text-2">
            <div className={`filename-jpg ${divClassName}`}>{text}</div>
            <div className={`upload-failed ${divClassNameOverride}`}>
              {states === "failed" && <>Upload failed</>}

              {states === "done" && <>500kb</>}
            </div>
          </div>
          <div className="action">
            {states === "failed" && (
              <>
                <DeleteOutline className="instance-node-2" color="#6D6D6D" />
                <Repeat className="instance-node-2" color="#6D6D6D" />
              </>
            )}

            {states === "done" && <HighlightOff1 className="instance-node-2" color="#858585" />}
          </div>
        </div>
      )}
    </div>
  );
};

UploadUrl.propTypes = {
  states: PropTypes.oneOf(["active", "default", "failed", "disabled", "done", "uploading-alt", "uploading"]),
  text: PropTypes.string,
};
