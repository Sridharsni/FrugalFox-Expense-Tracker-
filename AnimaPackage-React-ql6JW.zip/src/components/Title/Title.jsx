/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { ExpandMore14 } from "../../icons/ExpandMore14";
import { IosStyle1 } from "../../icons/IosStyle1";
import { IosStyle3 } from "../../icons/IosStyle3";
import { StyleRound6 } from "../../icons/StyleRound6";
import { Divider } from "../Divider";
import { SharpCorner } from "../SharpCorner";
import "./style.css";

export const Title = ({
  type,
  desc,
  div,
  className,
  divClassName,
  text = "Title Section",
  descClassName,
  text1 = "The quick brown fox jumps over the lazy dog",
  icon = <ExpandMore14 className="expand-more" color="#0B0B0B" />,
}) => {
  return (
    <div className={`title ${type} div-${div} desc-${desc} ${className}`}>
      <div className="master-general">
        <div className="wrapper">
          <div className="left">
            {!desc && <div className="title-section">{text}</div>}

            {desc && (
              <>
                <div
                  className={`title-section ${
                    (!div && type === "badge") ||
                    (!div && type === "link-badge") ||
                    (!div && type === "link") ||
                    (!div && type === "multi-trailing") ||
                    (!div && type === "single-trailing") ||
                    (!div && type === "toggle") ||
                    (!div && type === "value-trailing") ||
                    (!div && type === "value")
                      ? divClassName
                      : undefined
                  }`}
                >
                  {text}
                </div>
                <p
                  className={`desc ${
                    (!div && type === "badge") ||
                    (!div && type === "link-badge") ||
                    (!div && type === "link") ||
                    (!div && type === "multi-trailing") ||
                    (!div && type === "single-trailing") ||
                    (!div && type === "toggle") ||
                    (!div && type === "value-trailing") ||
                    (!div && type === "value")
                      ? descClassName
                      : undefined
                  }`}
                >
                  {text1}
                </p>
              </>
            )}
          </div>
          {(type === "badge" ||
            type === "link-badge" ||
            type === "link" ||
            type === "multi-trailing" ||
            type === "single-trailing" ||
            type === "toggle" ||
            type === "value-trailing" ||
            type === "value") && (
            <div className="right">
              {type === "toggle" && div && !desc && <IosStyle1 className="ios-style" />}

              {["link-badge", "link", "value"].includes(type) && (
                <div className="text-link">
                  {["link-badge", "link"].includes(type) && <>Text link</>}

                  {type === "value" && <>Value</>}
                </div>
              )}

              {type === "multi-trailing" && <StyleRound6 className="expand-more" color="#0B0B0B" />}

              {(type === "multi-trailing" || (div && type === "single-trailing")) && (
                <ExpandMore14 className="expand-more" color="#0B0B0B" />
              )}

              {type === "value-trailing" && (
                <>
                  <div className="text-wrapper">Value</div>
                  <ExpandMore14 className="expand-more" color="#0B0B0B" />
                </>
              )}

              {(type === "link-badge" || (div && type === "badge")) && (
                <SharpCorner
                  className="sharp-corner-instance"
                  color="primary"
                  filled={false}
                  size="tiny"
                  style="text"
                />
              )}

              {type === "toggle" && div && desc && <IosStyle3 className="ios-style" />}

              {!div && ["badge", "single-trailing", "toggle"].includes(type) && <>{icon}</>}
            </div>
          )}
        </div>
        {div && <Divider borderWeight="one-px" className="divider-instance" size="full" variants="solid" />}
      </div>
    </div>
  );
};

Title.propTypes = {
  type: PropTypes.oneOf([
    "value-trailing",
    "value",
    "default",
    "link-badge",
    "multi-trailing",
    "single-trailing",
    "link",
    "badge",
    "toggle",
  ]),
  desc: PropTypes.bool,
  div: PropTypes.bool,
  text: PropTypes.string,
  text1: PropTypes.string,
};
