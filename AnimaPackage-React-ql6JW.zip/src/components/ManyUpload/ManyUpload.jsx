/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Backup1 } from "../../icons/Backup1";
import { Divider } from "../Divider";
import "./style.css";

export const ManyUpload = ({
  states,
  style,
  className,
  divClassName,
  divClassNameOverride,
  divClassName1,
  text = "jpg, png, or svg",
}) => {
  return (
    <div className={`many-upload states-${states} ${className}`}>
      {style === "base" && ["default", "hover"].includes(states) && <Backup1 className="backup" />}

      {style === "alt" && ["default", "hover"].includes(states) && (
        <img className="upload" alt="Upload" src={states === "hover" ? "/img/upload-1.svg" : "/img/upload.svg"} />
      )}

      {["default", "hover"].includes(states) && (
        <div className="frame">
          <div className="text">
            {style === "alt" && <p className="div">Drag your file(s) to start uploading</p>}

            {style === "base" && (
              <>
                <div className={`div ${states === "default" ? divClassName : undefined}`}>Drag your file(s) or</div>
                <div className={`text-wrapper-2 ${states === "default" ? divClassNameOverride : undefined}`}>
                  browse
                </div>
              </>
            )}
          </div>
          {style === "base" && (
            <div className={`jpg-png-or-svg ${states === "default" ? divClassName1 : undefined}`}>{text}</div>
          )}

          {style === "alt" && (
            <>
              <Divider borderWeight="w-text" className="instance-node" size="full" text="OR" variants="solid" />
              <div className="outline">
                <div className="master-outline">
                  <button className="button">Browse files</button>
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {states === "hover" && (
        <div className={`drag-example ${style}`}>
          <div className="drag">
            <img className="document" alt="Document" src="/img/document-1.svg" />
            <div className="text-wrapper-3">theprojetks-design-tokens.zip</div>
          </div>
          <img className="img" alt="Drag" src={style === "alt" ? "/img/drag.svg" : "/img/drag-1.svg"} />
        </div>
      )}

      {states === "uploading" && (
        <>
          <div className={`progress-circular style-${style}`}>
            {style === "base" && (
              <div className="master-circle">
                <img className="content-area" alt="Content area" src="/img/contentarea.svg" />
              </div>
            )}

            {style === "alt" && <>Uploading...</>}
          </div>
          <div className={`frame-2 style-0-${style}`}>
            <div className="uploading">
              {style === "base" && <>Uploading...</>}

              {style === "alt" && <div className="master-linear" />}
            </div>
            <div className="outline-2">
              {style === "base" && (
                <button className="button-wrapper">
                  <button className="button-2">Cancel</button>
                </button>
              )}

              {style === "alt" && <>60%</>}
            </div>
          </div>
          <div className={`progress style-3-${style}`}>
            {style === "base" && <>60%</>}

            {style === "alt" && (
              <div className="outline">
                <button className="button-wrapper">
                  <button className="button-2">Cancel</button>
                </button>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

ManyUpload.propTypes = {
  states: PropTypes.oneOf(["uploading", "hover", "default"]),
  style: PropTypes.oneOf(["base", "alt"]),
  text: PropTypes.string,
};
