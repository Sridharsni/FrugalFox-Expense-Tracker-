export { SharpCorner } from "./SharpCorner";
