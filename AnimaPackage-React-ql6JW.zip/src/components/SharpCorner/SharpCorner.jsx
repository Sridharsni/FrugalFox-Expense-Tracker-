/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Info51 } from "../../icons/Info51";
import "./style.css";

export const SharpCorner = ({ size, color, style, filled, className }) => {
  return (
    <div className={`sharp-corner ${className}`}>
      <div className={`master-badges ${size} ${color} filled-${filled}`}>
        {["text", "trailing"].includes(style) && <div className="label-text">Badges</div>}

        {["leading", "trailing"].includes(style) && (
          <Info51
            className={`${size === "small" ? "class" : size === "tiny" ? "class-2" : "class-3"}`}
            color={
              !filled && color === "primary"
                ? "#1849D6"
                : !filled && color === "secondary"
                ? "#0EACB4"
                : !filled && color === "orange"
                ? "#FFA24D"
                : !filled && color === "green"
                ? "#1FBE42"
                : !filled && color === "red"
                ? "#FF3636"
                : color === "grey"
                ? "#545454"
                : color === "blue" && !filled
                ? "#1745C1"
                : "white"
            }
          />
        )}

        {style === "leading" && <div className="label-text-2">Badges</div>}
      </div>
    </div>
  );
};

SharpCorner.propTypes = {
  size: PropTypes.oneOf(["large", "tiny", "small"]),
  color: PropTypes.oneOf(["secondary", "primary", "grey", "blue", "green", "orange", "red"]),
  style: PropTypes.oneOf(["text", "trailing", "leading"]),
  filled: PropTypes.bool,
};
