import { SharpCorner } from ".";

export default {
  title: "Components/SharpCorner",
  component: SharpCorner,
  argTypes: {
    size: {
      options: ["large", "tiny", "small"],
      control: { type: "select" },
    },
    color: {
      options: ["secondary", "primary", "grey", "blue", "green", "orange", "red"],
      control: { type: "select" },
    },
    style: {
      options: ["text", "trailing", "leading"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    size: "large",
    color: "secondary",
    style: "text",
    filled: true,
    className: {},
  },
};
