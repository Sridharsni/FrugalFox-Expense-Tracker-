/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Divider = ({ variants, size, borderWeight, className, text = "Text" }) => {
  return (
    <div className={`divider ${borderWeight} ${variants} ${className}`}>
      {borderWeight === "w-text" && (
        <>
          <div className="line" />
          <div className="text-3">{text}</div>
          <div className="line-2" />
        </>
      )}
    </div>
  );
};

Divider.propTypes = {
  variants: PropTypes.oneOf(["solid", "dash"]),
  size: PropTypes.oneOf(["full"]),
  borderWeight: PropTypes.oneOf(["one-px", "three-px", "w-text", "two-px"]),
  text: PropTypes.string,
};
